########################################################################

### Summarization Results Exploration

### Collection of code for examining results of the ngram summarizer

### L. Miratrix


########################################################################




###########################################################################
## Functions to play with output from ngram summarizer
##
## by Luke Miratrix
###########################################################################


# convert phrases to search string.
make_search_phrases = function( phrases ) {
	if ( length( phrases ) == 0 ) {
		return( c() ) 
	}
	
	x = gsub( "*", "\\w*", phrases, fixed=TRUE )
	x = gsub( "+", "\\w*", x, fixed=TRUE )
		
	x = paste( "\\b", x, "\\b", sep="" )
	x
}



#' Examine phrases in an ad-hoc manner
#'
#' given list of phrases, count how many documents they appear in
#' and divide by positive and negative appearance.
#'
#' Phrases can have wildcards and stemming notation.  See grab.fragments.
#'
#' @seealso grab.fragments
#'
#' @return a dataframe of statistics.  per.pos is the percent of the 
#' documents with the phrase that are positively labeled.  per.tag is
#' the percent of the positively labeled documents that have the 
#' phrase.
#' 
#' @param phrases List of strings
#' @param labeling Vector of +1/0/-1 labels
#' @param corpus A corpus object from tm package
#' @family ngramCounting
#' @export
make.count.table = function( phrases, labeling, corpus ) {
	
	mcorp = corpus[labeling != 0]
	#print(mcorp)
	#	names(labeling) = unlist( meta( corpus, type="local", "ID" ) )
	
	cnts = sapply( phrases, function(x) { 
		x = gsub( "*", "\\w*", x, fixed=TRUE )
		#cat( "searching '", x, "'\n", sep="" )
		#pos = tm_index( mcorp, x )
		pos = tm_index(mcorp, FUN = function(doc) any(grep(x, doc)))
		#nab = unlist( meta( pos, type="local", "ID" ) )
		hits = labeling[pos]
		c( sum(hits > 0), length(hits) )
	} )
	
	rownames(cnts) = c("n.pos","n")
	res = data.frame( n.pos = cnts[1,], n=cnts[2,] )
	res$per.pos = round(100*res$n.pos/res$n)
	
	ntag = sum( labeling==1 )
	res$per.tag = round( 100 * res$n.pos / ntag )
	res	
}


#' @title Make a table of where phrases appear in a corpus
#'
#' @description
#' generate a phrase count matrix such as:
#'
#'  \\tabular{rrrrr}{
#'   0 \\tab 0 \\tab 0 \\tab 0 \\tab 0 \\cr
#'   1 \\tab 6 \\tab 2 \\tab 0 \\tab 0 \\cr
#'   8 \\tab 0 \\tab 0 \\tab 0 \\tab 0}
#'
#' @param phrase_list List of strings
#' @param corpus A corpus object from tm package
#' @return a n X p matrix, n being number of documents, p being number of phrases.
#' @family ngramCounting
#' @export
make.phrase.count.table = function( phrase_list, corpus ) {
	
	countmatches <- function(pattern,strings){
		#cat( "counting '", pattern, "'\n" )
		matchlist <-  gregexpr(pattern,strings)
		matchsimple <- sapply( matchlist, as.vector)
		matchnumbers <- sapply(matchsimple,function(x) if(any(is.na(x))|all(x == -1)) 0 else length(x))
		return(matchnumbers)
	}

	# the following makes the term-doc matrix for the phrases of interest
	phrases = make_search_phrases( phrase_list )
	phrasecount <-sapply(phrases,countmatches,corpus)	
	colnames(phrasecount) = phrase_list

	phrasecount
}



#' Count number of times a _single_ phrase appears in the corpus
#'
#' @param phrase A string
#' @param corp A corpus object from tm package
#' @family ngramCounting
#' @export
phrase.count = function( phrase, corp ) {
	stopifnot( length(phrase) == 1 )
	cnts = make.phrase.count.table( c( phrase ), corp )
	cnts[,1]
}







#' Grab all fragments in a corpus that have a given phrase.
#'
#' @description
#' Use like this \code{frags = grab.fragments( "israel", bigcorp )}
#'
#' Can take phrases such as 'appl+' which means any word starting with "appl."  
#' Can also take phrases such as "big * city" which consist of any three-word phrase with "big" 
#' as the first word and "city" as the third word.
#'
#' @param phrase Phrase to find in corpus
#' @param corp is a tm corpus
#' @param char.before Number of characters of document to pull before phrase to give 
#'        context.
#' @param char.after As above, but trailing characters.
#' @param cap.phrase TRUE if the phrase should be put in ALL CAPS.  False if left alone.
#' @param clean True means drop all documents without phrase from list. False means leave
#'    NULLs in the list.
#' @return fragments in corp that have given phrase.List of lists.  First list is 
#'       len(corp) long
#'  with NULL values for documents without phrase, and lists
#'   of phrases for those documents with the phrase
#' @export
grab.fragments = function( phrase, corp, char.before = 80, char.after=80, cap.phrase=TRUE, clean=FALSE ) {

	stopifnot( length( phrase ) == 1 )
	stopifnot( nchar(phrase) > 0 )
	
	if ( length(corp) == 0 ) {
		return( c() )	
	}
	phrase.exp= make_search_phrases(phrase)
	phrase.exp2 = paste( "(", phrase.exp, ")", sep="" )		

	a = gregexpr( phrase.exp, corp )
	res = lapply( 1:length(corp), function( k ) {
		spos = a[[k]]
		topk = attr(a[[k]], "match.length" ) + char.after - 1
		if ( spos[[1]] != -1 ) {
			strs = substring( corp[[ k ]], spos - char.before, spos + topk )
			if ( cap.phrase ) {
				strs = gsub( phrase.exp2, "\\U\\1", strs, perl=TRUE )
			} else {
				strs
			}
		} else {
			c()
		}
	} )
	names(res) = 1:length(corp)
	#npos = res[ sapply(res, length) > 0 ]
	#npos
	
	
	if ( clean ) {
		res.null = sapply( res, is.null )
		res = res[ !res.null ]
	}
	res
}




#' @title Sample fragments of text to contextualize a phrase.
#' 
#' @description
#' Take a phrase, a labeling and a corpus and return text fragments
#' with that phrase.
#'
#' Grab all phrases and then give sample of N from positive class
#' and N from negative class.  Sampling is to first sample from documents
#' and then sample a random phrase from each of those documents.
#'
#' @export
#' @import tm
#' @param phrases Phrases to examine (a list of strings)
#' @param labeling -- a vector of the same length as the corpus
#' @param corp Corpus object (tm package Corpus object)
#' @param N size of sample to make.
#' @param metainfo -- extra string to add to the printout for clarity if many such
#'     printouts are being generated.
#' @family sample.fragments
#' @examples
#' data( bathtub )
#' sample.fragments( "bathtub", meta(bathtub)$meth.chl, bathtub )
sample.fragments = function( phrases, labeling, corp, N=10, metainfo=NULL ) {
	
	stopifnot( "Corpus" %in% class(corp) )

	lb = labeling
	stopifnot( !is.null( lb ) )
	stopifnot( length(lb) == length(corp) )
	nP = sum( lb > 0 )
	nN = sum( lb < 0 )

	clusters = sapply( phrases, function( phrase ) {
		cnts = phrase.count( phrase, corp )
		
		selP = which( lb  > 0 & cnts > 0 )
		nfP = length(selP)	
		if ( nfP > N ) {
			selP = sort( sample( selP, N ) )
		}
		selN = which( lb  < 0 & cnts > 0 )
		nfN = length(selN)
		if ( nfN > N ) {
			selN = sort( sample( selN, N ) )
		}
		crpP = corp[selP]
		crpN = corp[selN]
		
		resP = grab.fragments( phrase, crpP )
		resN = grab.fragments( phrase, crpN )
		
		resP = sapply( resP, sample, 1 )
		resN = sapply( resN, sample, 1 )	
	
		#resP = sapply( resP, function(x) { gsub( ph, toupper(phrase), x ) } )
		#resN = sapply( resN, function(x) { gsub( ph, toupper(phrase), x ) } )
		
		fragment.sample =  list( phrase=phrase, resP=resP, resN=resN, metainfo=metainfo, nfP=nfP, nP=nP, nfN=nfN, nN=nN )
		class( fragment.sample ) = "fragment.sample"
		fragment.sample
	}, simplify=FALSE )
	
	clusters
}



#' Is object a fragment.sample object?
#' @export
#' @aliases fragment.sample
#' @param x the object to check.
#' @family sample.fragments
is.fragment.sample = function( x ) {
	inherits(x, "fragment.sample")
}






#' Pretty print results of phrase sampling object
#' @export
#' @param x A fragment.sample object.
#' @param ... No extra options passed.
#' @family sample.fragments
print.fragment.sample = function( x, ... ) {
	
	stopifnot( is.fragment.sample( x ) )
	
	with( x, {
		ph = make_search_phrases( phrase )
	
		pp = 100 * nfP/nP
		pn = 100 * nfN/nN
		
		if ( !is.null(metainfo) ) {
			cat( sprintf( "\nProfile of Summary Phrase: '%s' - %s", phrase, metainfo ) )
		} else {
			cat( sprintf( "\nProfile of Summary Phrase: '%s'", phrase ) )
		}
		cat( sprintf( "\nPositive: %d/%d = %.2f\nNegative: %d/%d = %.2f\nAppearance of '%s' in positively marked documents:\n", 
					nfP,nP,pp, nfN,nN, pn, phrase ) )
		
		sapply( resP, function(x) { cat( "* ", x, "\n", sep="" ) } )
		
		if ( !is.null(metainfo) ) {
			cat( sprintf( "\nAppearance of '%s' in baseline documents for %s:\n", phrase, metainfo ) )
		} else {
			cat( sprintf( "\nAppearance of '%s' in baseline documents.\n", phrase ) )
		}
		sapply( resN, function(x) { cat( "* ", x, "\n", sep="" ) } )
	} )
	invisible( x )	
}









