
#' Generate a matrix of the sequence of features as they are introduced with the ngram gradient descent 
#' program
#'
#' @family plot.path.matrix
#' @export
#' @param res A ngram.result object.
make.path.matrix = function( res ) {

	stps = res$path[[1]]
	stps.name = res$path[[2]]
	
	fets = unique( stps.name )
	
	mat = matrix( 0, ncol= length(fets), nrow=1+(length(stps)/2) )
	cur = rep( 0, length(fets) )
	names(cur) = fets

	for ( i in 1:(length(stps)/2) ) {
		cur[ stps.name[[i]] ] = cur[ stps.name[[i]] ] + stps[i]
		cur[ stps.name[[i+1]] ] = cur[ stps.name[[i+1]] ] + stps[i+1]
		mat[ i+1, ] = cur
	}
	attributes( mat )$features = fets
	mat
}


#' Plot the sequence of features as they are introduced with the ngram gradient descent 
#' program
#'
#' @export
#' @param res A ngram.result object or a matrix from the make.path.matrix call.
#' @family plot.path.matrix
path.matrix.chart = function( path.matrix, ... ) {
	if ( is.ngram.result( path.matrix ) ) {
		path.matrix = make.path.matrix( path.matrix )
	}
	fets = attributes(path.matrix)$features
	
	matplot( (1:nrow(path.matrix))/2, path.matrix, lty=1, col=1:length(fets), xlab="step", ylab="beta", bty="n", type="n" )
	abline( h=0, lty=3, col="grey" )
	matplot( (1:nrow(path.matrix))/2, path.matrix, type="l", lwd=2, lty=1, col=1:length(fets), bty="n", pch=19, add=TRUE )
	
	legend( "topright", fets, lty=1,col=1:length(fets), bty="n", cex=0.8, bg="white")
}



#' Plot the sequence of features as they are introduced with the ngram gradient descent 
#' program.
#' Simply calls path.matrix.chart.
#' @seealso path.matrix.chart
#'
#' @export
#' @param res A ngram.result object or a matrix from the make.path.matrix call.
#' @family plot.path.matrix
plot.ngram.result = function( object, ... ) {
	path.matrix.chart( object, ... )
}
