#' Given a VCorpus of original text, 
#' returns a VCorpus of stemmed text with '+' appended to all stemmed words. 
#'
#' This is expensive to run.
#'
#' Code based on code from Kevin Wu.
#'
#' @param corpus Original text
#' @param verbose True means do progress bar to watch progress.
#'
#' @examples
#' texts<- c('text 1', 'text 2', 'text 3')
#' corpus <- Corpus(VectorSource(texts))
#' stemmed_corpus<-stem.corpus(corpus)
stem.corpus <- function(corpus, verbose = TRUE) {
	
	stemmed_corpus <- tm_map(corpus, stemDocument)
	
	new_corpus <- rep(NA, length(corpus))
	stemmed_words <- c()
	if (verbose) {
		pb <- txtProgressBar(min = 0, max = length(corpus), style = 3)
	}

	for (i in 1:length(corpus)) {
		if (verbose) {
			setTxtProgressBar(pb, i/2)
		}

		orig <- strsplit(corpus[[i]], " ")[[1]]
		stem <- strsplit(stemmed_corpus[[i]], " ")[[1]]
		if (length(orig) != length(stem)) {
			if (length(stem) == 0) {
				cat( "missing doc is |", corpus[[i]], "|\n", sep="" )
				stem = c("")
			} else {
				cat( "missing doc is |", corpus[[i]], "|\n", sep="" )
				print(orig)
				cat("\n")
				print(stem)
	
				stop("Corpuses do not match up!")
				#If this is the case, check encodings of corpus and inputs
			}
		}
		dels = orig == stem
		new_corpus[i] = paste0(ifelse(dels, orig, paste0(stem, "+")), collapse = " ")
		stemmed_words = unique( c(stemmed_words, stem[!dels]) )
	}

	K = length(corpus)/2
	for (i in 1:length(new_corpus)) {
		if (verbose) {
			setTxtProgressBar(pb, K + i/2)
		}

		new_words <- strsplit(new_corpus[[i]], " ")[[1]]
		orig <- strsplit(corpus[[i]], " ")[[1]]

		ids = orig %in% stemmed_words
		new_words[ids] = paste0(new_words[ids], "+")
		new_corpus[i] = paste0(new_words, collapse = " ")
	}

	if (verbose) {
		close(pb)
	}
	rm( stemmed_corpus )
	return(Corpus(VectorSource(new_corpus)))
}



if (FALSE) {

	texts <- c("texting goblins the dagger", "text the goblin", "texting 3 goblins appl daggers goblining gobble")
	texts = rep(texts, 1000)

	corpus <- Corpus(VectorSource(texts))
	tm_map(corpus, stemDocument)
	as.character(tm_map(corpus, stemDocument))

	stemmed_corpus <- stem.corpus(corpus, tm_map(corpus, stemDocument))
	stemmed_words
	new_corpus

	as.character(stemmed_corpus)
}
