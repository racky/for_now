library(testthat)
test <- check("ngram")
