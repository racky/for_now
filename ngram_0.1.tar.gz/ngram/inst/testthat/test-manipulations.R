##
## test the phrase grabbing functions
##

# simple tests for ngram package
library( testthat )
library( ngram )

context( "Basic Utility Functions" )


# check phrase counting
test_that( "phrase.count.table", {
	mat = make.phrase.count.table( c( "a", "and", "bathtub", "falling", "asdfac", "stripper" ), bathtub )
	expect_equal( dim( mat ), c( length(bathtub), 6 ) )
	expect_equal( as.numeric(mat[2,]), c(5,2,1,1,0,0) )
} )




test_that( "phrase expansion works", {
	expect_equal( ngram:::make_search_phrases( "hi" ), "\\bhi\\b" )
	
	expect_equal( ngram:::make_search_phrases( c() ), c() )

	expect_equal( ngram:::make_search_phrases( NULL ), c() )
	
	expect_equal( ngram:::make_search_phrases( c( "A * B", "this *" ) ), c( "\\bA \\w* B\\b", "\\bthis \\w*\\b" ) )
		 
} )


test_that( "Order of parameters error trap is ok", {
	data( bathtub )

	expect_error( phrase.count( bathtub, "bathtub" ) )	
	
	res = phrase.count( "bathtub", bathtub )
	expect_equal( sum( res > 0 ), 16 )
	
	
	expect_error( grab.fragments( corp, "bathtub" ) )
} )


test_that( "Cap subphrase works", {
	docs = c( "987654321 test 123456789", "987654321 test word 123456789", "test at start", "a test b", "this is a test", "no test for hamsters", "without the t-word" )
	res = grab.fragments( "test", docs, char.before=4, char.after=4, clean=FALSE )
	expect_equal( as.character(res), c( "321 TEST 123", "321 TEST wor", "TEST at ",    "a TEST b",     "s a TEST",     "no TEST for", "NULL" ) )

	res = grab.fragments( "test *", docs, char.before=4, char.after=4, clean=FALSE )
	reslist = c( "321 TEST 123456789", "321 TEST WORD 123", "TEST AT sta",    "a TEST B",     "NULL",     "no TEST FOR ham", "NULL" )
	expect_equal( as.character(res), reslist )

	res = grab.fragments( "test *", docs, char.before=4, char.after=4, cap.phrase=FALSE )
	expect_equal( as.character(res)[1:4], tolower(reslist )[1:4] )

	res = grab.fragments( "test * hamsters", docs, char.before=4, char.after=4, clean=FALSE )
	expect_equal( as.character(res), c( "NULL", "NULL", "NULL", "NULL", "NULL", "no TEST FOR HAMSTERS", "NULL" ) )

	expect_error( grab.fragments( c("test","start"), docs, char.before=4, char.after=4, clean=FALSE ) )
	expect_error( grab.fragments( "", docs, char.before=4, char.after=4, clean=FALSE ) )

} )



context( "Searching for Phrases" )

test_that( "get list of subphrases right", {
	
	data( bathtub )
	
	# get labeling
	lab = meta( bathtub )$meth.chl
	head( lab )

	bans = c("methylene","chloride" )
	rs = ngram( bathtub, lab, bans, C=4, gap=1, verbosity=0 )		
	#rs
	
	tt = phrase.count( "paint", bathtub)
#	table( tt )

	chm = rs$model[ rs$model$ngram=="paint", ]
	expect_equal( sum( tt > 0 ), chm$totalDocs )
	expect_equal( sum( tt == 0 ), length(lab)-chm$totalDocs )
		
	tab = make.phrase.count.table( c( "paint", "bathtub", "tub * a" ), bathtub )
	expect_equal( as.numeric( table( tab[,1] ) ), 
				as.numeric( table( tt ) ) )
	

	ct = make.count.table( c( "paint", "vapors * heavier", "on the * floor", "bathtub", "tub * a", "bath", "stripper *" ), lab, bathtub )
#	ct
	
	mod = rs$model
	mod
	expect_equal( mod[ "vapors * heavier", "totalDocs" ], ct[ "vapors * heavier", "n" ] )
	expect_equal( mod[ "vapors * heavier", "posCount" ], ct[ "vapors * heavier", "n.pos" ] )
	expect_equal( mod[ "stripper *", "totalDocs" ], ct[ "stripper *", "n" ] )
	expect_equal( mod[ "stripper *", "posCount" ], ct[ "stripper *", "n.pos" ] )

#	table( tab$bathtub > 0, lab )

} )



test_that( "grabbing fragments works", {
	
	data( bathtub )
	expect_equal( length(bathtub), 127 )
	
	
	lab = meta( bathtub )$meth.chl
		
	# all appearances of "bathtub"
	tmp = grab.fragments( "bathtub", bathtub, char.before=20, char.after=20, 	clean=TRUE )
	
	expect_equal( as.numeric( table( sapply( tmp, length ) ) ), c( 13, 2, 1 ) ) # no faith in 13, 2, 1

	# looking at what "a bathtub" and "tub * a" are from
	frags = sample.fragments( "a bathtub", lab, bathtub, 20 )
#	print( frags )
	expect_output( frags, "Appearance of" )
	expect_output( frags, "Profile of Summary Phrase: 'a bathtub'" )
	expect_output( frags, "Positive: 5/17 = 29.41" )
	expect_output( frags, "on january XX XXXX an employee was refinishing A BATHTUB in a private residence the bathroom in which the employee was working was small" )
	
	#print( head(frags) )
	
	
	frags = sample.fragments( "tub * a", lab, bathtub, 20 )
	expect_output( frags, "Positive: 3/17 = 17.65" )
	expect_output( frags, "Negative: 0/110 = 0.00" )

	#print( head(frags) )
	
} )
