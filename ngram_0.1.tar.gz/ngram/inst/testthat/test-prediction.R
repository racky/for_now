
##
## test the prediction stuff
##

# simple tests for ngram package
library( testthat )
library( ngram )

context( "Testing Prediction" )





# check phrase counting
test_that( "phrase counting works", {
	data( testCorpora )
	
	res = ngram( c( "", "", "A", "A" ), c( -1, -1, 1, 1 ), C=1, Lp=1, convergence.threshold=0.00000001, verbosity=0 )
	res
	pds = predict( res )
	pds
	expect_equal( pds, c( -0.5, -0.5, 0.5, 0.5 ), tolerance=0.00001 )

	res = ngram( rep( "", 6 ), c( -1, -1, 1, 1, 1, 1 ), C=1, Lp=1, convergence.threshold=0.00000001, verbosity=0 )
	res
	pds = predict( res )
	pds
	expect_equal( pds, rep( 1/3, 6 ), tolerance=0.00001 )
	
	expect_equal( calc.loss( res )[[1]], 48/9 )
} )


# check phrase counting
test_that( "phrase counting works", {
	data( bathtub )
	mat = make.phrase.count.table( c( "a", "and", "bathtub", "falling", "asdfac", "stripper" ), bathtub )
	expect_equal( dim( mat ), c( length(bathtub), 6 ) )
	expect_equal( as.numeric(mat[2,]), c(5,2,1,1,0,0) )
} )



test_that( "Different ways of making rule matrices work", {

	data( bathtub )
	
	# get labeling
	lab = meta( bathtub )$meth.chl
	head( lab )
	
	res = ngram( bathtub, lab, C=2, verbosity=0 )
	keyphrase.mat = make.phrase.count.table( res$model$ngram, bathtub )
	keyphrase.mat[, "*intercept*"] = 1

	k2 = rule.to.matrix( res$rules, res$notes$n )

	expect_equal( k2, as.matrix( keyphrase.mat ) )

} )



test_that( "Both prediction paths work", {
	data( bathtub )
	
	# get labeling
	lab = meta( bathtub )$meth.chl
	head( lab )
	
	res = ngram( bathtub, lab, C=2, verbosity=0 )
	
	pds = predict( res )

	pds.rev = predict( res, rev( bathtub ) )
	
	expect_equal( pds, rev(pds.rev) )
	
} )




test_that( "Both prediction paths work for a null model", {
	data( bathtub )
	
	# get labeling
	lab = meta( bathtub )$meth.chl
	head( lab )
	
	res = ngram( bathtub, lab, C=20, verbosity=0 )
	
	pds = predict( res )

	pds.rev = predict( res, rev( bathtub ) )
	
	expect_equal( pds, rev(pds.rev) )
	
	keyphrase.mat = make.phrase.count.table( res$model$ngram, bathtub )
	expect_equal( dim( keyphrase.mat ), c(127, 1) )
	
} )




