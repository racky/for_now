##
## test dropping documents and different ways of giving corpus
## to ngram C++ function.
##

library( testthat )
library( ngram )

context( "Zero Labeling and Text Files " )


# check phrase counting
test_that( "simple drop zeros", {
	
	write( "A\nA A\nA B A\nA C A\nB\nC\nA", file="/tmp/testfile.txt" )
	
	corp = read.table( file="/tmp/testfile.txt", as.is=TRUE, header=FALSE, sep="\n" )$V1
	lab = c( 1, 1, 1, 0, 0, -1, 1 )
	data.frame( corp=corp, lab=lab )
	res = ngram( corp, lab, verbosity=0, positive.only=TRUE )
	res
	expect_equal( length( predict( res ) ), 5 )
	expect_equal( res$model$support, c(5, 6) )
	
	bcorp = Corpus( VectorSource( corp ) )
	res2 = ngram( corp, lab, verbosity=0, positive.only=TRUE )
	expect_equal( res, res2 )
	
	res3 = ngram( "/tmp/testfile.txt", lab, verbosity=0, positive.only=TRUE )
	res3
	expect_equal( res, res3 )

} )


