

# simple tests for ngram package
library( testthat )
library( ngram )


context( "cleaning text" )

test_that("dirtyBathtub check", {
	data( dirtyBathtub )
	data( bathtub )
	
	expect_equal( nrow(dirtyBathtub), length(bathtub) )
	
	bc = Corpus( VectorSource( dirtyBathtub$text ) )
	bc.clean = clean.text( bc )
	expect_equal( as.character(bathtub), as.character( bc.clean ) )
} )


